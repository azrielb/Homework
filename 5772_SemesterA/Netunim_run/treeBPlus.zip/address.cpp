#include "Address.h"
#include <iomanip>
Address::Address(const string & n, const string & e, const string & f, const string & p, const string & sA) 
	: name(n), email(e), fax(f), phone(p), streetAddress(sA)
{ 
}

ostream& operator<<(ostream & os, const Address & adrs) {
	os << "Name: " << left << setw(6) << (adrs.name + ".") 
		<< "\tEmail: " << left << setw(17) << (adrs.email + ".") 
		<< "\tPhone: " << setw(12) << right << (adrs.phone + ". ") 
		<< "Fax: " << setw(12) << right << (adrs.fax + ". ") 
		<< "Street Address: " << adrs.streetAddress << '.';
	return os;
}

bool Address::operator== (const string & key) const {
	return GetKey() == key;
}
bool Address::operator!= (const string & key) const {
	return GetKey() != key;
}
bool Address::operator<(const string & key) const {
	return GetKey() < key;
}
bool Address::operator>(const string & key) const {
	return GetKey() > key;
}
bool Address::operator<=(const string & key) const {
	return GetKey() <= key;
}
bool Address::operator>=(const string & key) const {
	return GetKey() >= key;
}
bool Address::operator== (const Address & other) const {
	return GetKey() == other.GetKey();
}
bool Address::operator!= (const Address & other) const {
	return GetKey() != other.GetKey();
}
bool Address::operator<(const Address & other) const {
	return GetKey() < other.GetKey();
}
bool Address::operator>(const Address & other) const {
	return GetKey() > other.GetKey();
}
bool Address::operator<=(const Address & other) const {
	return GetKey() <= other.GetKey();
}
bool Address::operator>=(const Address & other) const {
	return GetKey() >= other.GetKey();
}
