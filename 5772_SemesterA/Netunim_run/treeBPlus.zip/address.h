#pragma once
#include <string>
#include <iostream>
using namespace std;

class Address
{
public:
	//A single constructor
	//Remark: this class do not dynamicly allocate memory, therefore it does not need a destructor, a copy constructor etc.
	Address(const string & n = "anonymous", const string & e = "N/A", const string & f = "N/A", const string & p = "N/A", const string & sA = "N/A");
	//return the key
	string GetKey() const { return email; }
	//comparing functions - the "Address" can be compared with other "Address" or with a string
	
	bool operator== (const string & key) const;
	bool operator!= (const string & key) const;
	bool operator<(const string & key) const;
	bool operator>(const string & key) const;
	bool operator<=(const string & key) const;
	bool operator>=(const string & key) const;
	bool operator== (const Address & other) const;
	bool operator!= (const Address & other) const;
	bool operator<(const Address & other) const;
	bool operator>(const Address & other) const;
	bool operator<=(const Address & other) const;
	bool operator>=(const Address & other) const;
	//Overloading the stream-operator "<<" - for "cout"
	friend ostream & operator<< (ostream & os, const Address & adrs);
protected:
	string streetAddress;
	string email;
	string phone;
	string fax;
	string name;
};
