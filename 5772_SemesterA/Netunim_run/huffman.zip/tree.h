#pragma once
#include <map>
#include <queue>
#include "Node.h"

class tree
{
private:
	class NodeComparing {
	public:
		bool operator()(Node * a, Node * b) {
			return *a > *b;
		}
	};
	typedef priority_queue<Node *, vector<Node *>, NodeComparing> node_priority_queue;
	// fields
	map<char, unsigned long long> letters;
	Node * root;
	// build the tree from priority queue of "node" pointers
	void buildTree(node_priority_queue & strings);
	// build the the table from the tree
	void buildTable();
	void treeToTable(Node * node, unsigned long long code = 1);
public:
	tree();
	virtual ~tree();
	unsigned long long encodeLetter(char letter);
	char decodeLetter(unsigned long long code);
	string encodeText(string text);
	string decodeText(string coded);
};
