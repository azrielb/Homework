#include <cmath>
#include "tree.h"
#include "convertions.h"

tree::tree() {
	letters = map<char, unsigned long long>();
	root = NULL;
}
tree::~tree() {
	if (root != NULL)
		delete root;
}
void tree::buildTree(node_priority_queue & strings) {
	if (strings.size() == 0) return;
	if (strings.size() == 1) {
		root = strings.top();
		strings.pop();
		return;
	}
	while (true) {
		Node * x = strings.top();
		strings.pop();
		Node * y = strings.top();
		strings.pop();
		root = new Node(x, y);
		if (root == NULL) throw "error in memory allocation";
		if (strings.empty()) break;
		strings.push(root);
	}
}
void tree::buildTable() {
	letters.clear();
	treeToTable(root);
}
void tree::treeToTable(Node * node,	unsigned long long code) {
	if (node == NULL) return;
	if (node->getLeft() != NULL) {
		treeToTable(node->getLeft(), code << 1);
		treeToTable(node->getRight(), (code << 1) | 1);
	} else {
		letters[node->getLetter()] = code;
	}
}
unsigned long long tree::encodeLetter(char letter) {
	return letters[letter];
}
char tree::decodeLetter(unsigned long long code) {
	for(map<char, unsigned long long>::iterator it = letters.begin(); it != letters.end(); ++it)
		if (it->second == code)
			return it->first;
	return NULL;
}
string tree::encodeText(string text) {
	map<char, unsigned> chars = map<char, unsigned>();
	node_priority_queue strings = node_priority_queue();
	for (string::const_iterator theText = text.begin(); theText != text.end(); ++theText)
		++(chars[*theText]);
	for (map<char, unsigned>::iterator it = chars.begin(); it != chars.end(); ++it) {
		Node * node = new Node(it->first, it->second);
		if (node == NULL) throw "error in memory allocation";
		strings.push(node);
	}
	buildTree(strings);
	buildTable();

	string coded = "";
	for(map<char, unsigned>::iterator it = chars.begin(); it != chars.end(); ++it) {
		coded += it->first + UintToString(it->second);
	}
	coded = (char)(coded.length() / 5) + coded;
	if (root->getLeft() == NULL) // the all letters are the same, like this string "777777777777777"
		return coded;
	char temp = 1;
	int counter = 1;
	string codedText = "";



	string::const_iterator theText = text.end();
	do {
		--theText;
		unsigned long long num = letters[*theText];
		int length = (int)(log((double)num) / log((double)2));
		num &= ~(1 << length);
		temp |= num << counter;
		while (length + counter > 7) {
			codedText = temp + codedText;
			temp = (char)(num >>= (8 - counter));
			length -= (8 - counter);
			counter = 0;
		}
		counter += length;
	} while(theText != text.begin());
	return coded + ((counter == 0) ? codedText : temp + codedText);




	// old version
	for (string::const_iterator theText = text.begin(); theText != text.end(); ++theText) {
		unsigned long long num = letters[*theText];
		counter += (int)(log((double)num) / log((double)2) + 1);
		if (counter > 7) {
			counter -= 8;
			temp |= num >> counter;
			coded += temp;
			temp = 0;
		}
		temp |= num << (8 - counter);
	}
	return (counter == 0) ? coded : coded + temp;
}
string tree::decodeText(string coded) {
	static const int CharAndFrequency = sizeof(char) + sizeof(unsigned);
	static const int SizeOfChar = sizeof(char);
	string text = "";
	string::const_iterator theText = coded.begin();
	if ((int)coded.length() - 1 <= *theText) return ""; // no data...
	node_priority_queue strings = node_priority_queue();
	for(char counter = *(theText++); counter; --counter) {
		Node * node = new Node(*theText, StringToUint(string(theText + SizeOfChar, theText + CharAndFrequency)));
		if (node == NULL) throw "error in memory allocation";
		strings.push(node);
		theText += CharAndFrequency;
	}
	buildTree(strings);
	buildTable();
	if (root->getLeft() == NULL) // the all letters are the same, like this string "777777777777777"
		return string(root->getFrequency(), root->getLetter());
	Node * node = NULL;
	while (theText != coded.end()) {
		char current = *(theText++);
		for (unsigned char mask = 0x80; mask; mask >>= 1) {
			if (node == NULL) { // this is like a flag
				if (!current) 
					break;
				node = root;
				if (current == 1) {
					break;
				}
				while (!(current & mask))
					mask >>= 1;
				mask >>= 1;
			}
			if (current & mask) {
				node = node->getRight();
				if (node->getRight() == NULL) {
					text += node->getLetter();
					node = root;
				}
			} else {
				node = node->getLeft();
				if (node->getLeft() == NULL) {
					text += node->getLetter();
					node = root;
				}
			}
		}
	}
	return text;
}
