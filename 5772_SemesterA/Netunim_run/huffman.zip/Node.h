#pragma once
#include <string>
using namespace std;
class Node
{
private:
	char text;
	unsigned frequency;
	Node * left;
	Node * right;
public:
	Node(char t, unsigned f); // constructor for a leaf
	Node(Node * l = NULL, Node * r = NULL); // constructor for internal node (not a leaf)
	virtual ~Node();

	//properties
	Node * getLeft();
	Node * getRight();
	char getLetter();
	unsigned getFrequency();

	//comparing function - compare by frequency
	bool operator== (const Node & other) const;
	bool operator!= (const Node & other) const;
	bool operator<(const Node & other) const;
	bool operator>(const Node & other) const;
	bool operator<=(const Node & other) const;
	bool operator>=(const Node & other) const;
};
