#pragma once
#include <string>
using namespace std;

string UintToString(unsigned num);
unsigned StringToUint(const string & str);
