#include "Node.h"

Node::Node(char t, unsigned f) : text(t), frequency(f), left(NULL), right(NULL) { 
}
Node::Node(Node * l, Node * r) : text(NULL), frequency(l->frequency + r->frequency), left(l), right(r) { 
}
Node::~Node()
{
	if (left != NULL) {
		delete left;
		delete right;
	}
}

Node * Node::getLeft() {
	return left;
}
Node * Node::getRight() {
	return right;
}
char Node::getLetter() {
	return left != NULL ? NULL : text;
}
unsigned Node::getFrequency() {
	return frequency;
}

bool Node::operator==(const Node & other) const { return frequency == other.frequency; }
bool Node::operator!=(const Node & other) const { return frequency != other.frequency; }
bool Node::operator< (const Node & other) const { return frequency <  other.frequency; }
bool Node::operator> (const Node & other) const { return frequency >  other.frequency; }
bool Node::operator<=(const Node & other) const { return frequency <= other.frequency; }
bool Node::operator>=(const Node & other) const { return frequency >= other.frequency; }
